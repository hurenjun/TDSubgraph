package stats;

public class Cluster {
	public int m_size;
	public double m_posScore;
	public double m_negScore;
	
	public Cluster(int size,double posScore,double negScore)
	{
		// initialize
    	m_size = size;
		m_posScore=posScore;
    	m_negScore=negScore;
	}
	    	
	public double cost(double LB,double r_P,double r_N,double m_s) 
	{
		if (m_size <= 1)
		{
			return m_size;
		}
		
		return 1 + m_size*(1-prob(LB, m_posScore, m_negScore,r_P,r_N,m_s));
	}
	
	public double prob(double LB, double posScore,double negScore, double r_P, double r_N, double s)
	{
		return ProbLib.Phi(
				( LB/(m_posScore - r_P * m_posScore - r_N * m_negScore)  -1)
				/s);
	}
	
};
