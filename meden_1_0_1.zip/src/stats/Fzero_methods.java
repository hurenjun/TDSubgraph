package stats;


public interface Fzero_methods {

   double f_to_zero(double x);

}
