package stats;

public interface Gaus8_fcn {

   double f_to_integrate(double x);

}
