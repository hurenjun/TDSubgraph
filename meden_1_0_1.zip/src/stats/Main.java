package stats;
import java.io.*;

class Main {
    public static void main(String[] args) throws IOException {
        
    	
    	System.out.println("Phi(-2)=" + ProbLib.PhiCheck(-2.0)+ " " + ProbLib.Phi(-2.0)); 
    	System.out.println("Phi(-1)=" + ProbLib.PhiCheck(-1)+ " " + ProbLib.Phi(-1.0)); 
    	System.out.println("Phi(0)=" + ProbLib.PhiCheck(0)+ " " + ProbLib.Phi(0)); 
    	System.out.println("Phi(1)=" + ProbLib.PhiCheck(1)+ " " + ProbLib.Phi(1.0)); 
    	System.out.println("Phi(2)=" + ProbLib.PhiCheck(2)+ " " + ProbLib.Phi(2.0)); 
        
    	System.out.println("partialPositiveFirstMoment(-2,1)=" + ProbLib.partialPositiveFirstMomentCheck(-2.0,1.0)+ " " + ProbLib.partialPositiveFirstMoment(-2.0,1)); 
    	System.out.println("partialPositiveFirstMoment(-1,1)=" + ProbLib.partialPositiveFirstMomentCheck(-1,1)+ " " + ProbLib.partialPositiveFirstMoment(-1.0,1)); 
    	System.out.println("partialPositiveFirstMoment(0,1)=" + ProbLib.partialPositiveFirstMomentCheck(0,1)+ " " + ProbLib.partialPositiveFirstMoment(0,1)); 
    	System.out.println("partialPositiveFirstMoment(1,1)=" + ProbLib.partialPositiveFirstMomentCheck(1,1)+ " " + ProbLib.partialPositiveFirstMoment(1.0,1)); 
    	System.out.println("partialPositiveFirstMoment(2,1)=" + ProbLib.partialPositiveFirstMomentCheck(2,1)+ " " + ProbLib.partialPositiveFirstMoment(2.0,1)); 
    	
    	System.out.println("partialPositiveFirstMoment(-2,2)=" + ProbLib.partialPositiveFirstMomentCheck(-2.0,2)+ " " + ProbLib.partialPositiveFirstMoment(-2.0,2)); 
    	System.out.println("partialPositiveFirstMoment(-1,2)=" + ProbLib.partialPositiveFirstMomentCheck(-1,2)+ " " + ProbLib.partialPositiveFirstMoment(-1.0,2)); 
    	System.out.println("partialPositiveFirstMoment(0,2)=" + ProbLib.partialPositiveFirstMomentCheck(0,2)+ " " + ProbLib.partialPositiveFirstMoment(0,2)); 
    	System.out.println("partialPositiveFirstMoment(1,2)=" + ProbLib.partialPositiveFirstMomentCheck(1,2)+ " " + ProbLib.partialPositiveFirstMoment(1.0,2)); 
    	System.out.println("partialPositiveFirstMoment(2,2)=" + ProbLib.partialPositiveFirstMomentCheck(2,2)+ " " + ProbLib.partialPositiveFirstMoment(2.0,2)); 
    	
    	System.out.println("partialNegativeFirstMoment(-2,1)=" + ProbLib.partialNegativeFirstMomentCheck(-2.0,1.0)+ " " + ProbLib.partialNegativeFirstMoment(-2.0,1)); 
    	System.out.println("partialNegativeFirstMoment(-1,1)=" + ProbLib.partialNegativeFirstMomentCheck(-1,1)+ " " + ProbLib.partialNegativeFirstMoment(-1.0,1)); 
    	System.out.println("partialNegativeFirstMoment(0,1)=" + ProbLib.partialNegativeFirstMomentCheck(0,1)+ " " + ProbLib.partialNegativeFirstMoment(0,1)); 
    	System.out.println("partialNegativeFirstMoment(1,1)=" + ProbLib.partialNegativeFirstMomentCheck(1,1)+ " " + ProbLib.partialNegativeFirstMoment(1.0,1)); 
    	System.out.println("partialNegativeFirstMoment(2,1)=" + ProbLib.partialNegativeFirstMomentCheck(2,1)+ " " + ProbLib.partialNegativeFirstMoment(2.0,1)); 
    	
    	System.out.println("partialNegativeFirstMoment(-2,2)=" + ProbLib.partialNegativeFirstMomentCheck(-2.0,2)+ " " + ProbLib.partialNegativeFirstMoment(-2.0,2)); 
    	System.out.println("partialNegativeFirstMoment(-1,2)=" + ProbLib.partialNegativeFirstMomentCheck(-1,2)+ " " + ProbLib.partialNegativeFirstMoment(-1.0,2)); 
    	System.out.println("partialNegativeFirstMoment(0,2)=" + ProbLib.partialNegativeFirstMomentCheck(0,2)+ " " + ProbLib.partialNegativeFirstMoment(0,2)); 
    	System.out.println("partialNegativeFirstMoment(1,2)=" + ProbLib.partialNegativeFirstMomentCheck(1,2)+ " " + ProbLib.partialNegativeFirstMoment(1.0,2)); 
    	System.out.println("partialNegativeFirstMoment(2,2)=" + ProbLib.partialNegativeFirstMomentCheck(2,2)+ " " + ProbLib.partialNegativeFirstMoment(2.0,2)); 
 
    	System.out.println("meanMaxCheck(-2,2, -1.0,1, 0)=" + ProbLib.meanMaxCheck(-2.0,2, -1.0,1, 0)+ " " + ProbLib.meanMax(-2.0,2, -1.0,1, 0)); 
    	System.out.println("meanMaxCheck(-1,2, -1.0,1, 0)=" + ProbLib.meanMaxCheck(-1,2, -1.0,1, 0)+ " " + ProbLib.meanMax(-1,2, -1.0,1, 0)); 
    	System.out.println("meanMaxCheck(0,2, -1.0,1, 0)=" + ProbLib.meanMaxCheck(0,2, -1.0,1, 0)+ " " + ProbLib.meanMax(0,2, -1.0,1, 0)); 
    	System.out.println("meanMaxCheck(1,2, -1.0,1, 0)=" + ProbLib.meanMaxCheck(1,2, -1.0,1, 0)+ " " + ProbLib.meanMax(1,2, -1.0,1, 0)); 
    	System.out.println("meanMaxCheck(2,1, 1.0,2, 0)=" + ProbLib.meanMaxCheck(2,1, 1.0,2, 0)+ " " + ProbLib.meanMax(2,1, 1.0,2, 0)); 
    	
    	System.out.println("stdevMaxCheck(-2,2, -1.0,1, 0)=" + ProbLib.stdevMaxCheck(-2.0,2, -1.0,1, 0)+ " " + ProbLib.stdevMax(-2.0,2, -1.0,1, 0)); 
    	System.out.println("stdevMaxCheck(-1,2, -1.0,1, 0)=" + ProbLib.stdevMaxCheck(-1,2, -1.0,1, 0)+ " " + ProbLib.stdevMax(-1,2, -1.0,1, 0)); 
    	System.out.println("stdevMaxCheck(0,2, -1.0,1, 0)=" + ProbLib.stdevMaxCheck(0,2, -1.0,1, 0)+ " " + ProbLib.stdevMax(0,2, -1.0,1, 0)); 
    	System.out.println("stdevMaxCheck(1,2, -1.0,1, 0)=" + ProbLib.stdevMaxCheck(1,2, -1.0,1, 0)+ " " + ProbLib.stdevMax(1,2, -1.0,1, 0)); 
    	System.out.println("stdevMaxCheck(2,1, 1.0,2, 0)=" + ProbLib.stdevMaxCheck(2,1, 1.0,2, 0)+ " " + ProbLib.stdevMax(2,1, 1.0,2, 0)); 
    	
    	System.out.println("stdevMaxCheck(0,1, 0,1, 0)=" + ProbLib.stdevMaxCheck(0,1, 0,1, 0)+ " " + ProbLib.stdevMax(0,1, 0,1, 0)); 

    	//IntervalMatrix matrix = new IntervalMatrix();
        //matrix.read("posmat.dat","negmat.dat");
        
                
        
    }
}

