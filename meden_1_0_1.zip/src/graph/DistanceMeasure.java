package graph;

public interface DistanceMeasure {
	public double getD(int v1,int v2);
	public double min();
	public double max();
	public double avg();
	public int numelems();
}
