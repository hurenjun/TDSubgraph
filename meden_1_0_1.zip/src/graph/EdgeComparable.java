package graph;

public class EdgeComparable implements Comparable<EdgeComparable>{
	public Integer n1=-1, n2=-1;
	public Double dist = -1.0;
	
	public EdgeComparable(int an1,int an2,double adist) {
		n1=an1; n2 = an2;
		dist=adist;
	}
	
	public int compareTo( EdgeComparable ae ) {
		
		if (dist.compareTo(ae.dist) != 0) {
			assert(0!=((Integer)Math.min(n1, n2)).compareTo((Integer)Math.min(ae.n1, ae.n2)) ||
					0!=((Integer)Math.max(n1, n2)).compareTo((Integer)Math.max(ae.n1, ae.n2))):"Edges with the same ednpoints of different dist"; 
			return dist.compareTo(ae.dist);
		} else { // dist are equal
			if(0==((Integer)Math.min(n1, n2)).compareTo((Integer)Math.min(ae.n1, ae.n2))) {
				return ((Integer)Math.max(n1, n2)).compareTo((Integer)Math.max(ae.n1, ae.n2));
			} else return ((Integer)Math.min(n1, n2)).compareTo((Integer)Math.min(ae.n1, ae.n2));
		}
	}
	
	@Override
	public String toString() {
		return n1 + "-" + n2 + ":" + dist;  
	}
	
	public static void main(String[] args) {
		EdgeComparable e1 = new EdgeComparable(0, 1, 10.0);
		EdgeComparable e2 = new EdgeComparable(20, 1, 1.0);
		EdgeComparable e4 = new EdgeComparable(0, 2, 10.0);
		EdgeComparable e5 = new EdgeComparable(0, 0, 10.0);
		
		
		EdgeComparable e3 = new EdgeComparable(0, 1, 1.0);
		
		assert (e1.compareTo(e2) > 0);
		assert (e1.compareTo(e4) < 0);
		assert (e1.compareTo(e5) > 0);
		
		//e3.compareTo(e1);
		
	}
	
}
