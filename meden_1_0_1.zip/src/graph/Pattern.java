package graph;

import java.util.BitSet;

public class Pattern {
	public final int s;
	public final int e;
	public final BitSet edges;
	public final double score;
	public Pattern(int start, int end, BitSet seledges, double sc) {
		s = start;
		e = end;
		edges = seledges;
		score = sc;
	}
	public String toString() {
		String res = "[" + s + "," + e + "]" + score + "\n";
		res += edges.toString();
		return res;
	}
	
	public boolean equals(Pattern o) {
		boolean res = true;
		if(Math.abs(score - o.score) > 0.00001) res = false;
		if(s != o.s || e != o.e) res = false;
		if(!edges.equals(o.edges)) res = false;
		return res;
	}
}
