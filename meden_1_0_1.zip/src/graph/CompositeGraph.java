package graph;

import java.util.Arrays;

public class CompositeGraph {
	Graph[] gs;
	public CompositeGraph(Graph[] gs_) {
		gs = gs_;
		for (Graph g: gs) {
			g.aggVolumesInWn();
			g.buildN2I();
		}
	}
	
	public CompositeGraph(Graph g) {
		gs = new Graph[1];
		gs[0] = g;
		gs[0].aggVolumesInWn();
		gs[0].buildN2I();
	}
	
	public Graph mix(double[] mixture) {
		if (null == mixture) {
			// Either a single layer or even mix
			if (gs.length == 1) {
				return gs[0];
			} else {
				mixture = new double[gs.length];
				Arrays.fill(mixture, 1.0/mixture.length);
			}
		}
		//TODO()
		Graph g = null;
		g.aggVolumesInWn();
		return g;
	}

}
