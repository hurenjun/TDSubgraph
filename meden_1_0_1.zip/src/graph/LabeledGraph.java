package graph;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;

import misc.Common;

public class LabeledGraph extends Graph {
	public String[] nlab;
	public LabeledGraph(Graph g, String[] labels) {
		super(g);
		assert(labels.length == g.getn());
		nlab = labels;
	}
	
	public double lsim(String n1, String n2) {
		return lsim(n2i.get(n1), n2i.get(n2));
	}
	
	// Computes the similarity of labels assigned to two nodes as
	// |L1 n L2|/|L1 U L2|
	public double lsim(int n1, int n2) {
		double res = -1;
		if (nlab[n1].equals("") || nlab[n2].equals("")) return 0;
		String[] L1 = nlab[n1].split(Common.SEP);
		String[] L2 = nlab[n2].split(Common.SEP);
		
		HashSet<String> LS1 = new HashSet<String>();
		for (String s: L1) LS1.add(s);
		HashSet<String> LS2 = new HashSet<String>();
		for (String s: L2) LS2.add(s);
		HashSet<String> intersect = new HashSet<String>();
		intersect.addAll(LS1);
		intersect.retainAll(LS2);
		
		res = intersect.size();
		intersect.addAll(LS1);
		intersect.addAll(LS2);
		return res / intersect.size();
	}
}
