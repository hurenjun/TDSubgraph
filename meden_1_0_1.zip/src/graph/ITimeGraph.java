package graph;

public interface ITimeGraph extends IGraph{
	public int gett();
	public void aggregateByTime(int s, int e, double[] weights);
	public void aggregateByTime(int s, int e);
	public Graph getGraph();
	public float[][] getTimeseries();
}
