package graph;

public interface IGraph {
	public int getm();
	public int getn();
	public int ind(int i);
	public int endv(int i);
	public double we(int i);
	public double wn(int i);
}
