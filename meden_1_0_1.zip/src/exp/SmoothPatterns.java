package exp;

import generator.GraphGenerator;
import graph.Graph;
import graph.TimeGraph;

import index.IntervalBounds;
import index.IntervalIndexExactCeiling;

import java.io.IOException;
import java.util.Arrays;

import misc.Common;
import misc.IO;
import misc.Time.t_res;

public class SmoothPatterns {
	public static void main(String[] args) throws IOException {
		TimeGraph tg = null;
		int n = 500;
		int m = 1000;
		double N = 0.3;
		double T = 0.9;
		double nz = 0.1;
		//int trials = 50;
		int trials = 10;
		int k = 10;
		int times[] = {100,500,1000,1500,2000};
		double[] alphas = {0.5, 0.7, 0.9};
		
		// TRAFFIC
//		tg = IO.readTGraphPems(Common.DATA_DIR + "PeMS/d07_stations_2010_08_18.graph", 
//		   Common.DATA_DIR + "PeMS/d07_text_station_5min_2011_04.txt.timeseries");
//		nz = tg.scoreEdgesPvalueTODDOW(0.01,24);
//		tg.buildN2I();
//		IO.writeTGraphQuadruplesLogOdds(Common.DATA_DIR + "PeMS/tgraph.01.quadruples", tg);
//		IO.writeTGraph(Common.DATA_DIR + "PeMS/d07.tgraph.01", tg);
//		tg = IO.readTGraph(Common.DATA_DIR + "PeMS/d07.tgraph.005");
		
		
//		TimeGraph tg100 = tg.getBFSSubgraph(0, 100, 0, tg.gett()-1);
//		IO.writeTGraph(Common.DATA_DIR + "PeMS/tg100",tg100);
//		IO.writeTGraphQuadruples(Common.DATA_DIR + "PeMS/tg100.quadruples", tg);
		
		TimeGraph tg100 = IO.readTGraph(Common.DATA_DIR + "PeMS/tg100");
//		
		int s = 0, e = 1000; 
		int time = e-s+1;
		double alpha = 0.4;
//		
//		// OURS
		BoundUtility.runCoarse(tg100, s, e, time, alpha, 10, new RunMesasurements(), false);
		//runIncreasingTime(times,trials,tg, "TRAFFIC", alphas, k);
	}
}
