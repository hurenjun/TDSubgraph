package exp;

import graph.CompositeGraph;
import graph.LabeledGraph;
import gsearch.TopK;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;

import misc.Common;
import misc.ComparableLabeledValue;
import misc.ExtToolsDriver;
import misc.IO;

public class EIvsRWR {
	
	public static void LabelSimVsProximity(LabeledGraph lg, int k, String name) {
		TopK qp = new TopK(new CompositeGraph(lg));
		HashMap<Integer,Double> ns = new HashMap<Integer, Double>();
		
		double[][] sim = new double[k][2];
		
		int cnt = 0;
		for (int j=0; j < lg.getn(); j++) {
//		for (int trials=0; trials < 200; trials++) {
//			int j = Common.rand.nextInt(lg.getn());
			if (lg.nlab[j].equals("")) continue;
			
			ns.clear();
			ns.put(j, 1.0);
			ComparableLabeledValue[] tm = qp.getActualEI(ns, 0.1, null);
			
			addToRes(lg.names[j], lg, tm,sim, 0);

			// Normalize the RWR
			for(int i = 0 ; i < tm.length; i++) 
				tm[i].v = tm[i].v / lg.wn[lg.n2i.get(tm[i].l)];
			Arrays.sort(tm);
			addToRes(lg.names[j], lg, tm,sim, 1);
			
			cnt++;
		}
		
		String[] x = new String[sim.length];
		for (int i = 1; i < k+1; i++) {
			sim[i-1][0] /= cnt;
			sim[i-1][1] /= cnt;
			x[i-1] = "" + (i);
		}
		String[] curves = {"RWR", "EI"};
		ExtToolsDriver.plotCurves(x,curves, sim, "Position", "Average Label Similarity", name, Common.GSEARCH_DATA_DIR );
	}
	
	private static void addToRes(String origin, LabeledGraph lg, ComparableLabeledValue[] tm, double[][] sim, int sim_column) {
		System.err.print(tm[0].l + " " + lg.nlab[lg.n2i.get(tm[0].l)] + " --> ");
		int i = 0;
		double avg = 0;
		for( int pos = 0; pos < tm.length; pos++) {
			double val = 0;
			if (tm[pos].l.equals(origin)) continue;
//			for (int p1 = 0; p1 <= i; p1++) {
//				for (int p2 = p1+1; p2 <=i; p2 ++) {
//					val += lg.lsim(tm[p1].l, tm[p2].l)/((i+1)*i/2);
//				}
//			}
			
			val = lg.lsim(origin, tm[pos].l);
			
			//avg += val;
			avg += (val>0)?1:0;
			//sim[i][sim_column] += val;
			sim[i][sim_column] += (val>0)?1:0;
			
			System.err.print(lg.nlab[lg.n2i.get(tm[pos].l)] + "(" +val+ ":" + tm[pos].v + ")|\t");
			i++;
			if (i == sim.length) break;
		}
		System.err.print("\n" + avg / sim.length + "\n" );
		if (sim_column == 1) System.err.print("\n");
	}

	public static void main(String[] args) throws Exception{
		//Graph g = IO.readGraphEdgeList(Common.GSEARCH_DATA_DIR + "test100");
		
		
//		HashSet<String> remove = new HashSet<String>();
//		remove.add("GO:0008150"); remove.add("GO:0005575"); remove.add("GO:0003674");
//		
//		String go = "proc";
//		String org = "yeastnet";
//		LabeledGraph lg = IO.readGraphEdgeListNodeLabeled(Common.GSEARCH_DATA_DIR + "/function_prediction/" +org+ "/edges", 
//				   Common.GSEARCH_DATA_DIR + "/function_prediction/" +org+ "/pin_nodes_"+go+".txt", 0, remove);
//		LabelSimVsProximity(lg, 20, "celegans_"+go+"_dist");
		
		
//		HashSet<String> remove = new HashSet<String>();
//		LabeledGraph lg = IO.readGraphEdgeListNodeLabeled(Common.GSEARCH_DATA_DIR + "/function_prediction/wiki/edges.0.10000", 
//				   Common.GSEARCH_DATA_DIR + "/function_prediction/wiki/cat.0.10000", 4, remove);
//		LabelSimVsProximity(lg, 50, "wiki_dist");
		
		HashSet<String> remove = new HashSet<String>();
		LabeledGraph lg = IO.readGraphEdgeListNodeLabeled(Common.GSEARCH_DATA_DIR + "/osn/youtube.edges.5000.1000", 
				   Common.GSEARCH_DATA_DIR + "/osn/youtube.groups.5000.1000", 4, remove);
		LabelSimVsProximity(lg, 50, "youtube_dist");
	}
}
