package exp;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;

import misc.Common;

public class Experiment {
	public final HashMap<String,String> params = new HashMap<String, String>();
	public final String fn;
	public double[][] data;
	public String[] traces;
	
	public Experiment(HashMap<String,String> _param, String _fn) {
		params.putAll(_param);
		fn = _fn;
	}
	
	public void saveResults() {
		try {
			BufferedWriter bwd = new BufferedWriter(new FileWriter(Common.EXP_DIR + fn + ".csv"));
			BufferedWriter bwm = new BufferedWriter(new FileWriter(Common.EXP_DIR + fn + ".meta"));
			for (int i = 0; i < data.length; i++) {
				for (int j = 0; j < data[0].length; j++ ) {
					bwd.write(data[i][j] + "\t");
				}
				bwd.write("\n");
			}
			bwd.close();
			for (int i = 0; i < traces.length; i++) {
				bwm.write(traces[i] + "\t");
			}
			bwm.write("\n");
			for (String param: params.keySet()) {
				bwm.write(param + "\t" + params.get(param) + "\n");
			}
			bwm.close();
		} catch (Exception e) {
			System.err.print("Could not save experimental results\n");
			e.printStackTrace();
			System.exit(1);
		}
	}
	
}
