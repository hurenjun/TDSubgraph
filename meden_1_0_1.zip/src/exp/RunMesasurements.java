package exp;

import misc.Common;

public class RunMesasurements {
	// times
	public long index_t;
	public long coarsen_t;
	public long sop_t;
	public long lb_t;
	public long ub_t;
	public long veri_t;
	
	// nums
	public int ubs_n;
	public int ubs_all;
	public int veri_n;
	public int veri_all;
	
	// pruning
	public int sopcoarse_p;
	public int ubcoarse_p;
	public int sop_p;
	public int ub_p;
	public int veri_p;
	
	// values
	public double best_lb;
	
	public void clear() {
		index_t = 0;
		coarsen_t = 0;
		sop_t = 0;
		lb_t = 0;
		ub_t = 0;
		veri_t = 0;
		ubs_n = 0 ;
		ubs_all = 0;
		veri_n = 0;
		veri_all = 0;
		best_lb = 0.0; 
		sopcoarse_p = 0;
		ubcoarse_p = 0;
		sop_p = 0;
		ub_p = 0;
		veri_p = 0;
	}
	
	public long sumTime() {
		return index_t + coarsen_t + sop_t + lb_t + ub_t + veri_t;
	}
	
	public int sumPruned() {
		return sopcoarse_p + ubcoarse_p + sop_p + ub_p + veri_p;
	}
	
	public String toString() {
		String res = "";
		res +=  		"VALUES:\tlb: " + best_lb + "\t" +
								"numubs:" +  ubs_n +  " of " + ubs_all + 
								"\t numverify " + veri_n + " of " + veri_all + "\n";
		res += "TIMES:\t"+
				"ind:" + index_t + "\t" + 
				"sop:" + sop_t + "\t" + 
				"coar:" + coarsen_t + "\t" +
				"lb:" + lb_t + "\t" +
				"ub:" + ub_t + "\t" +
				"veri:" + veri_t + "\t" +
				"\n";
		
		res += "Pruned:\t"+
		"coarse sop:" + sopcoarse_p + "\t" + 
		"coarse ub:" + ubcoarse_p + "\t" + 
		"sop:" + sop_p + "\t" +
		"ub:" + ub_p + "\t" +
		"veri:" + veri_p + "\t" +
		"\n";
		
		res += "Pruned %:\t"+
		"coarse sop:" + Common.oneDigitFormat.format(100.0*sopcoarse_p/sumPruned()) + "\t" + 
		"coarse ub:" + Common.oneDigitFormat.format(100.0*ubcoarse_p/sumPruned()) + "\t" + 
		"sop:" + Common.oneDigitFormat.format(100.0*sop_p/sumPruned()) + "\t" +
		"ub:" + Common.oneDigitFormat.format(100.0*ub_p/sumPruned()) + "\t" +
		"veri:" + Common.oneDigitFormat.format(100.0*veri_p/sumPruned()) + "\t" +
		"\n";
		
		return res;
	}
	
}
