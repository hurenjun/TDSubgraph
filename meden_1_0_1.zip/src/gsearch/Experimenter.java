package gsearch;

import java.util.ArrayList;
import java.util.BitSet;
import java.util.Random;

import misc.Common;
import misc.ExtToolsDriver;
import misc.Visualizer;
import generator.GraphGenerator;
import graph.Graph;
import gsearch.Sparsifier.Functions;


public class Experimenter {
	// Experiment 1: Time and improvement over meden for increasing intervals
	public static void CompareSparseFixedPart(String fn, String outdir, 
			double r, int numparts, String datalab, double[] percentages) throws Exception{
			System.out.print("Running " + fn + "\nr=" + r + "\nclusters=" + numparts +"\n");
		
//			Graph g = misc.IO.readGraphEdgeList("/home/petko/data/gsearch/grid/grid.sorted",false);
			Graph g = misc.IO.readGraphEdgeList(fn,false); 
//			Graph g = GraphGenerator.generateScaleFreeWeighted(1000, 10, 100); datalab="randsf";
//			Graph g = GraphGenerator.generateRandomWeighted(500, 10000, 80, 100); datalab="rand";
			Random ra = new Random();
			for (int i = 0; i < g.getm(); i++) {
				g.we[i] = ra.nextDouble()*1000; 
				g.we[g.getReverseEdgeIndex(i)] = g.we[i] ;
			}
			g = g.getLargestConnectedComponent();
			
			// ORIGINAL
			ArrayList<String> po = ExtToolsDriver.partitionGraph(g, numparts);
			
//	        int[] interval_sizes = {20, 50, 100, 200};
	        double[] pcs = {0.05,0.1,0.3,0.5,0.7,0.9};
	        if (null != percentages) pcs = percentages;
	        
			//String[] names = { "Meden+",  "Exp", "CC" , "PCST", "PCST+", "PCST++"};
			String[] names = { "Orig",  "GS", "LS" , "RW", "EI"};
			double ncut[][] = new double[pcs.length][names.length];
			double cond[][] = new double[pcs.length][names.length];
			for (int j = 0; j < pcs.length; j++) {
				double pc = pcs[j];
				System.out.print("Percentage " + pc + "\n");
				
				ncut[j][0] = Common.avgNCut(po,g);
				cond[j][0] = Common.avgConductance(po,g);
				
				
				
				// LOCAL
				BitSet el = Sparsifier.sparsifyJCLocal(pc, g);
				Graph gl = g.keepEdges(el);
				ArrayList<String> pl = ExtToolsDriver.partitionGraph(gl, numparts);
				ncut[j][2] = Common.avgNCut(pl,g);
				cond[j][2] = Common.avgConductance(pl,g);
//				Visualizer.visualize(gl);
				
				// update the pc
				pc = gl.getm()*1.0/g.getm();
				pcs[j] = pc;
				
				
				// GLOBAL
				BitSet eg = Sparsifier.sparsifyJCGlobal(pc, g);
				Graph gg = g.keepEdges(eg);
				ArrayList<String> pg = ExtToolsDriver.partitionGraph(gg, numparts);
				ncut[j][1] = Common.avgNCut(pg,g);
				cond[j][1] = Common.avgConductance(pg,g);
//				Visualizer.visualize(gg);
				
				Sparsifier.FUNC_K = Functions.EXP;
				// RW
				BitSet ew = Sparsifier.sparsifyDynamicK(pc, g, r,false);
				Graph gw = g.keepEdges(ew);
				ArrayList<String> pw = ExtToolsDriver.partitionGraph(gw, numparts);
				ncut[j][3] = Common.avgNCut(pw,g);
				cond[j][3] = Common.avgConductance(pw,g);
//				Visualizer.visualize(gw);
				
				// EI
				BitSet er = Sparsifier.sparsifyDynamicK(pc, g, r, true);
				Graph gr = g.keepEdges(er);
				ArrayList<String> pr = ExtToolsDriver.partitionGraph(gr, numparts);
				ncut[j][4] = Common.avgNCut(pr,g);
				cond[j][4] = Common.avgConductance(pr,g);
//				Visualizer.visualize(gr);
				
				System.out.print("IE-Glob: " + Common.jc(er, eg) + "\n");
				System.out.print("IE-Loc: " + Common.jc(er, el) + "\n");
				System.out.print("IE-RW: " + Common.jc(er, ew) + "\n");
				
				System.out.print(pc);
				for (int i=1;i<names.length;i++)System.out.print("\t" + String.format("%.2f", cond[j][i]/cond[j][0]) );
				System.out.print("\n");
				
			}
			String[] x = new String[pcs.length]; 
			for (int i=0; i < pcs.length ; i++) x[i] = String.format("%.2f", pcs[i]);
			
			ExtToolsDriver.plotCurves(x,names, ncut, 
									  "Sparsification Ratio", 
									  "Normalized Cut", 
									  "exp1_ncut" + "_" +datalab+ "_" + numparts, outdir);
			ExtToolsDriver.plotCurves(x,names, cond, 
					  "Sparsification Ratio", 
					  "Average Conductance", 
					  "exp1_cond" + "_" +datalab+ "_" + numparts, outdir);
	}
	
	public static void main(String[] args) throws Exception{
		misc.Common.enablePlotting = true;
		misc.Common.SEP = ",";
		//1 /home/petko/data/gsearch/grid/ grid.sorted /home/petko/Dropbox/paper_gsearch/img/ 0.3 2 
		int exp = Integer.parseInt(args[0]);
		if (exp == 1) {
			String data_dir = args[1];
			String fn = args[2];
			String outdir = args[3];
			double r = Double.parseDouble(args[4]);
			int numparts = Integer.parseInt(args[5]);
			double[] pcs = null;
			if (args.length==7) {
				String[] pcss = args[6].split(",");
				pcs = new double[pcss.length];
				for (int i=0;i < pcss.length;i++) pcs[i] = Double.parseDouble(pcss[i]);
			}
			CompareSparseFixedPart(data_dir + "/" + fn, outdir, r, numparts,fn,pcs);
		} else if (exp == 2) {
			
		}
	}
}
