package alg;

import java.util.ArrayList;

public class TimeGraphSolution implements Comparable<TimeGraphSolution>{
	ArrayList<Integer> edges = new ArrayList<Integer>();
	int start=-1, end=-1;
	Double score = -1.0;
	
	public int compareTo( TimeGraphSolution aTGS ) {
		return score.compareTo(aTGS.score);
	}
}
	
