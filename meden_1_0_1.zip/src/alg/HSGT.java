package alg;

import java.util.ArrayList;
import java.util.HashSet;

import generator.GraphGenerator;
import graph.Graph;
import graph.TimeGraph;
import graph.Tree;

public class HSGT {
	
	public static TimeGraphSolution getTopTimeGraphExhaustive(TimeGraph tg) {
		TimeGraphSolution max = new TimeGraphSolution();
		TimeGraphSolution tmp;
		Graph g; 
		Tree t;
		BUp bup;
		for (int i=0; i<tg.gett(); i++) {
			for (int j=i; j<tg.gett(); j++) {
				// compute edges
				tg.aggregateByTime(i,j);
				
				// transform edges to nodes keep mapping
				bup = new BUp(tg.getAggNodeWeighted());
				
				// solve opt in transformed
				//t = bup.getOptimal();
				t = null; //bup.getLookAheadGrow();
				
				tmp = new TimeGraphSolution();
				tmp.start = i; tmp.end = j;
				tmp.score = t.getScore();
				
				if (tmp.compareTo(max) > 0) {
					// get positive edges in contained clusters
					// in the found solution t 
					for (int c=0; c < t.getn(); c++) {
						tmp.edges.addAll(tg.getPositiveEdgesAmong(tg.aggnode_map.get(c)));
					}
					// translate form transform graph edges to original for the 
					// negative edges
					int edge_idx = -1;
					for(int n=0; n<t.getn();n++){
						for (int m = t.endv[n]; m < t.endv[n+1]; m++) {
							edge_idx = tg.translateNegEdge(
										tg.getEdgeIndex(
												tg.getNodeIndex(t.names[t.getOrigin(m)]), 
												tg.getNodeIndex(t.names[t.endv[m]])
												)
										);
							assert(!tmp.edges.contains(edge_idx)):"Trying to reinsert the edge";
							tmp.edges.add(edge_idx);
						}
					}
					max = tmp;
				} 
			}
		}
		return max;
	}
	
	public static void main(String[] argv) {
		int n = 400, m = 300, t = 100;
		double Pn = 0.005, Pp = 0.05, Ps = 0.001; // settings
		//Graph gbase = GraphGenerator.getTestGraphWithStarFurtherMerge();
		//Graph gbase = GraphGenerator.generateScaleFree(n);
		Graph gbase = GraphGenerator.generateRandom(n,(int)(1.2*n));
		TimeGraph tg = GraphGenerator.generateTimeGraphLocalized(t, Pn, Pp, Ps, gbase);
		System.err.print(tg);
		TimeGraphSolution tgs = getTopTimeGraphExhaustive(tg);
		System.err.println("Done");
		
	}
}
