package generator;

public class DynamicModel {
	public double PNextGivenCurrent = -1;
	public double PNeighbor = -1;
	public double POne = -1;
	public double NConnectPositive = -1;
	public double AvgLength = -1;
	
	public String toString() {
		return "P(+):" + POne + "\nP(N+|I+):" + PNeighbor + "\nP(Next+|Prev+):" + 
				PNextGivenCurrent + "\t";
	}
}
