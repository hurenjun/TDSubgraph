package generator;

import org.jgrapht.VertexFactory;

public class VertexGenerator implements VertexFactory<Integer> {
	int id=0;
	@Override
	public Integer createVertex() {
		return id++;
	}

}