package index;

import graph.Graph;
import graph.TimeGraph;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

public class CoarseIndexEntry{
	public int s, e;
	// maybe switch to arrays?
	public HashMap<Integer,Integer> partition;
	public HashMap<Integer,ArrayList<Integer>> part_edges;
	public HashMap<String,String> joints;
	int nparts;
	public Graph g;
	
	public CoarseIndexEntry(int start, int end) {
		s = start;
		e = end;
	}
	public HashMap<Integer,ArrayList<Integer>> getPartSets(TimeGraph tg){
		if (part_edges==null) {
			part_edges = new HashMap<Integer, ArrayList<Integer>>();
			for (int e:partition.keySet()) {
				if(!part_edges.containsKey(partition.get(e))) 
					part_edges.put(partition.get(e), new ArrayList<Integer>());
				part_edges.get(partition.get(e)).add(e);
				part_edges.get(partition.get(e)).add(tg.getReverseEdgeIndex(e));
			}
		}
		return part_edges;
	}
}
