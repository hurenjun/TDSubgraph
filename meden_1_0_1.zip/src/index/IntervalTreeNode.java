package index;

import misc.Common;

public class IntervalTreeNode {
	public int from;
	public int to;
	public double[] w;
	public IntervalTreeNode L = null, R = null;
	public IntervalTreeNode(int _from, int _to, double[] v) {
		from = _from;
		to = _to;
		w = v;
	}
	@Override
	public String toString() {
		return "IntervalTreeNode [from=" + from + ", to=" + to + "]";
	}
	public void aggregate(int s, int e, double[] v, boolean onlyPositive) {
		int overlap = Common.overlap(s,e,from,to);
		
		if (0 == overlap) {
			return;
			
		} else if (overlap == to-from+1) {
			//the whole interval of trhe node is contained
			// aggregate
			for (int i = 0; i < w.length; i++) {
				if (onlyPositive && w[i] <= 0) 
					continue;
				else 
					v[i] += w[i];
			}
			System.err.print(this.toString() + " x " + overlap +"\n");
		} else {
			L.aggregate(s, e, v, onlyPositive);
			R.aggregate(s, e, v, onlyPositive);
		}
		
	}
}
