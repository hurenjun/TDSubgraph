package index;

import misc.Common;

public class IntervalTreeNodeExactCeiling {
	public final int from, to;
	// this is the ceiling of all intervals 
	// with the same starting position that are powers of 2
	public final double[] ceiling_left;
	//public final double[] ceiling_right;
	public final double[] w;
	public IntervalTreeNodeExactCeiling L = null, R = null;
	
	public IntervalTreeNodeExactCeiling(int _from, int _to, double[] _w, double[] _vl) {
		from = _from;
		to = _to;
		w = _w;
		ceiling_left = _vl;
	}
	
	@Override
	public String toString() {
		return "IntervalTreeNode [from=" + from + ", to=" + to + "]";
	}

	public void ceilingLeft(int s, int e, double[] ve, double[] vc) {
		int overlap = Common.overlap(s,e,from,to);
		if (0 == overlap) {
			return;
		} else if (overlap == to-from+1) {
			//the whole interval of the node is contained
			for (int i = 0; i < w.length; i++) {
				// 1. update the ceiling
				vc[i] = Math.max(vc[i], ve[i] + ceiling_left[i]);
				// 2. update the aggregate vector
				ve[i] += w[i];
			}
			//System.err.print(this.toString() + " x " + overlap +"\n");
		} else {
			L.ceilingLeft(s, e, ve, vc);
			R.ceilingLeft(s, e, ve, vc);
		}
	}
	
	public void aggregate(int s, int e, double[] ve) {
		int overlap = Common.overlap(s,e,from,to);
		if (0 == overlap) {
			return;
		} else if (overlap == to-from+1) {
			//the whole interval of the node is contained --> aggregate
			for (int i = 0; i < w.length; i++) ve[i] += w[i];
			//System.err.print(this.toString() + " x " + overlap +"\n");
		} else {
			L.aggregate(s, e, ve);
			R.aggregate(s, e, ve);
		}
	}
	
}
