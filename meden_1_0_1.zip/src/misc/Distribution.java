package misc;

import java.util.ArrayList;
import java.util.TreeSet;

public class Distribution {
	ArrayList<Double> vals = new ArrayList<Double>();
	public void add(double v){
		int pos = 0;		
		if(vals.size()==0) {
			vals.add(v);
		}else{
			while (pos < vals.size() && v >= vals.get(pos)) pos++;
			vals.add(pos, v);
		}
		
	}
	
	public double score(double v, double logodsnorm) {
		double logods = (-1)*Math.log(pvalue_lt(v)/logodsnorm);
		if (logods > 10 && logods < 80 ) {
			System.err.print(logods);
		}
		
		if (logods < -100) {
			return -100;
		} else if (logods > 100) {
			return 100; 
		} else return logods;
	}
	
	public static float[][] scoreAllPValues(float[][] pv, float logoddsnorm) {
		float[][] scores = new float[pv.length][pv[0].length];
		for(int i =0; i < pv.length; i++) {
			for (int j = 0 ; j < pv[0].length; j++) {
				scores[i][j] = (float)((-1)*Math.log(pv[i][j]/logoddsnorm));
				scores[i][j] = Math.min(scores[i][j], 100);
				scores[i][j] = Math.max(scores[i][j], -100);
			}
		}
		return scores;
	}
	
	
	public float pvalue_gt(double v) {
		int pos = 0;
		while (pos < vals.size() && v > vals.get(pos)) pos++;
		double pv  = 1.0 - (Math.min(pos, vals.size()))*1.0 / vals.size();
		return (float)pv;
	}
	
	public float pvalue_lt(double v) {
		int pos = 0;
		while (pos < vals.size() && v >= vals.get(pos)) pos++;
		double pv  = (Math.min(pos, vals.size()))*1.0 / vals.size();
		return (float)pv;
	}
	
	
	public void clean() {
		vals.clear();
	}
}
