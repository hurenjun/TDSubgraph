package misc;

public class ComparableFix implements Comparable<ComparableFix>{
	public Integer tstart;
	public Integer tend;
	public Integer index;
	public Float cost;
	public boolean add;
	public int srcnd;
	public int dstnd;
	
	public ComparableFix(int ts, int te, int ind, float cst, boolean toAdd, int src, int dest) {
		tstart = ts;
		tend = te;
		index = ind;
		add = toAdd;
		cost = cst;
		srcnd = src;
		dstnd = dest;
	}
	@Override
	public int compareTo(ComparableFix o) {
		if (cost.compareTo(o.cost) == 0) {
			if (add == o.add) {
				if (index.compareTo(o.index) ==0) {
					if (tstart.compareTo(o.tstart) == 0) {
						return tend.compareTo(o.tend);
					} else {
						return tstart.compareTo(o.tstart);
					}
				} else { // indices different
					return index.compareTo(o.index);
				}
			} else {
				// prefer additions over deletions
				if (add) return 1;
				else return -1;
			}
		} else { // costs different
			return cost.compareTo(o.cost);
		}
	}
	
	public boolean sameIndexTime(ComparableFix o) {
		return (o.getIndexTime().equals(getIndexTime()));
	}
	
	@Override
	public String toString() {
		return (add?"+ ":"- ") + srcnd + "-" +dstnd + "[" + tstart + "-" + tend + "]:" + cost; 
	}
	
	public String getIndexTime() {
		return index + "_" + tstart + "_" + tend;
	}
}