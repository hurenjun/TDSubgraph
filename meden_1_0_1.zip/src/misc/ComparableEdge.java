package misc;

public class ComparableEdge implements Comparable<ComparableEdge> {
	public Double w;
	public Integer il;
	public Integer ih;
	public Integer v1;
	public Integer v2;
	
	public ComparableEdge (double _w, int _il, int _ih, int _v1, int _v2) {
		w = _w;
		il = _il;
		ih = _ih;
		v1 = _v1;
		v2 = _v2;
	}
	
	@Override
	public int compareTo(ComparableEdge o) {
		if(w.compareTo(o.w) != 0) return  w.compareTo(o.w);
		else return il.compareTo(o.il);
	}
	
	@Override
	public String toString() {
		return v1 + "-" + v2 + "[" + w + "]";
	}

}
