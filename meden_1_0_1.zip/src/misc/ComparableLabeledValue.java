package misc;

public class ComparableLabeledValue implements Comparable<ComparableLabeledValue>{
	public String l;
	public Double v;
	public ComparableLabeledValue(String lab, Double val) {
		l = lab; v = val;
	}
	@Override
	public int compareTo(ComparableLabeledValue o) {
		if (v.compareTo(o.v) == 0) return l.compareTo(o.l);
		else return (-1)*v.compareTo(o.v);
	}
	
	@Override
	public String toString() {
		return l + ":" + v; 
	}
}
