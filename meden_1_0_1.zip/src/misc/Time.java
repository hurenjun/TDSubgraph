package misc;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public class Time {
	public enum t_res {H, D, W, M, Y};
	// start and end are in seconds since 1970
	public static long[] discretizeInterval(long s, long e, t_res res) {
		long ss = -1, ee = -1;
		Calendar c = Common.cal;
		int field = -1;
		switch (res) {
			case H: 
				field=Calendar.HOUR;
				c.setTimeInMillis(s*1000);
				c.set(Calendar.MINUTE, 0);c.set(Calendar.SECOND,0);
				ss = c.getTimeInMillis()/1000;
				c.setTimeInMillis(e*1000);
				c.set(Calendar.MINUTE, 0);c.set(Calendar.SECOND,0);
				c.add(field, 1);
				ee = c.getTimeInMillis()/1000;
				break;
			case D:
				field=Calendar.DATE;
				c.setTimeInMillis(s*1000);
				c.set(Calendar.HOUR, 0);c.set(Calendar.MINUTE, 0);c.set(Calendar.SECOND,0);
				ss = c.getTimeInMillis()/1000;
				c.setTimeInMillis(e*1000);
				c.set(Calendar.HOUR, 0);c.set(Calendar.MINUTE, 0);c.set(Calendar.SECOND,0);
				c.add(field, 1);
				ee = c.getTimeInMillis()/1000;
				break;
			case W:
				field = Calendar.WEEK_OF_YEAR;
				c.setTimeInMillis(s*1000);
				c.set(Calendar.HOUR, 0);c.set(Calendar.MINUTE, 0);c.set(Calendar.SECOND,0);
				ss = c.getTimeInMillis()/1000;
				c.setTimeInMillis(e*1000);
				c.set(Calendar.HOUR, 0);c.set(Calendar.MINUTE, 0);c.set(Calendar.SECOND,0);
				c.add(field, 1);
				ee = c.getTimeInMillis()/1000;
				break;
			case M:
				field=Calendar.MONTH;
				c.setTimeInMillis(s*1000);
				c.set(Calendar.DATE, 1);c.set(Calendar.HOUR, 0);c.set(Calendar.MINUTE, 0);c.set(Calendar.SECOND,0);
				ss = c.getTimeInMillis()/1000;
				c.setTimeInMillis(e*1000);
				c.set(Calendar.DATE, 1);c.set(Calendar.HOUR, 0);c.set(Calendar.MINUTE, 0);c.set(Calendar.SECOND,0);
				c.add(field, 1);
				ee = c.getTimeInMillis()/1000;
				break;
			case Y:
				field=Calendar.YEAR;
				c.setTimeInMillis(s*1000);
				c.set(Calendar.MONTH, 0);c.set(Calendar.DATE, 1);c.set(Calendar.HOUR, 0);c.set(Calendar.MINUTE, 0);c.set(Calendar.SECOND,0);
				ss = c.getTimeInMillis()/1000;
				c.setTimeInMillis(e*1000);
				c.set(Calendar.MONTH, 0);c.set(Calendar.DATE, 1);c.set(Calendar.HOUR, 0);c.set(Calendar.MINUTE, 0);c.set(Calendar.SECOND,0);
				c.add(field, 1);
				ee = c.getTimeInMillis()/1000;
				break;
		}
		ArrayList<Long> pivots = new ArrayList<Long>();
		
		while(ss<ee) {
			pivots.add(ss);
			c.setTimeInMillis(ss*1000);
			//System.err.print(DateFormat.getInstance().format(c.getTime()) + "\n");
			c.add(field, 1);
			ss = c.getTimeInMillis()/1000;
		}
		pivots.add(ss);
		//System.err.print(DateFormat.getInstance().format(c.getTime()) + "\n");
		
		// get the beginning of the period (according to the res)
		
		
		long[] result = new long[pivots.size()];
		for (int i=0; i < pivots.size(); i++) result[i] = pivots.get(i);
		return result;
	}
	
	public static void main(String[] args) {
		discretizeInterval(940000000, 1020000000, t_res.H);
	}
}
