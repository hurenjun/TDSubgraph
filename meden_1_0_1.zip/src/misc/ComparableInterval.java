package misc;

import java.util.Arrays;

public class ComparableInterval implements Comparable<ComparableInterval>{
	public int pos, size;
	public Double val;
	public Double act = -1.0;
	public double[] w;
	public double Probability;
	public ComparableInterval(int _pos, int _size, double _v) {
		pos = _pos;
		size = _size;
		val = _v;
	}
	public ComparableInterval(int _pos, int _size, double _v, double[] _w) {
		pos = _pos;
		size = _size;
		val = _v;
		w = Arrays.copyOf(_w, _w.length);
	}
	
	public boolean sameInterval(int sz, int p) {
		return sz == size && pos == p;
	}
	
	@Override
	public int compareTo(ComparableInterval o) {
		if (val.compareTo(o.val) != 0) return val.compareTo(o.val);
		else if(((Integer)pos).compareTo(o.pos) != 0 ) return ((Integer)pos).compareTo(o.pos);
		else return ((Integer)size).compareTo(o.size);
	}
	public String toString() {
		if(act < 0) {
			return "[" + pos + "-" + (pos+size) + "] " + val.toString();
		}else{
			return "[" + pos + "-" + (pos+size) + "] " + act.toString() + "(" + val.toString() + ")";
		}
	}
}
