package misc;

public class ComparableIndexedValue implements Comparable<ComparableIndexedValue>{
	public Integer ind;
	public Double v;
	public ComparableIndexedValue(Integer id, Double val) {
		ind = id; v = val;
	}
	@Override
	public int compareTo(ComparableIndexedValue o) {
		if (v.compareTo(o.v) == 0) return ind.compareTo(o.ind);
		else return v.compareTo(o.v);
	}
	
	@Override
	public String toString() {
		return ind + ":" + v; 
	}
}
