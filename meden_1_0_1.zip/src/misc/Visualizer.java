package misc;

import java.util.BitSet;
import java.util.HashSet;

import graph.Graph;

public class Visualizer {
	
	public static void visualize(Graph g) {
		BitSet edges = new BitSet(g.getm());
		edges = new BitSet();
		edges.set(0, g.getm());
		visualize(g, edges);
	}
	
	public static void visualize(Graph g, HashSet<Integer> edg) {
		BitSet edges = new BitSet(g.getm());
		if (edg == null) {
			edges = new BitSet();
			edges.set(0, g.getm());
		} else {
			for (Integer e: edg) edges.set(e);
		}
		visualize(g, edges);
	}
	
	public static void visualize(Graph g, BitSet edges) {
		if (edges == null) {
			edges = new BitSet();
			edges.set(0, g.getm());
		}
		
		String res = "graph G { \n";
		res += edgesToGraphViz(g,edges);
		res += "}";
		ExtToolsDriver.saveGraphViz(res);
		ExtToolsDriver.showGraphViz();
	}
	
	private static String edgesToGraphViz(Graph g, BitSet edges) {
		String res = "";
		for (int i=0; i < g.getn(); i++) {
			for (int j = g.ind[i]; j < g.ind[i+1]; j++){
				if (edges.get(j) && i < g.endv[j]) {
//					res += "\"" + g.names[i] + "\" -- \"" + 
//							g.names[g.endv[j]] + "\" [ label = " + String.format("%.2f", g.we[j]) + "];\n";
					res += "\"" + g.names[i] + "\" -- \"" + 
						g.names[g.endv[j]] + "\";\n";
				}
			}
		}
		return res;
	}
}