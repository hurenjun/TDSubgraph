package misc;

public class ComparableCluster implements Comparable<ComparableCluster> {
	public Double s, n;
	public ComparableCluster(double _s, double _n) {
		s = _s;
		n = _n;
	}
	
	@Override
	public int compareTo(ComparableCluster o) {
		return s.compareTo(o.s);
	}
	public String toString() {
		return "(" + s + "," + n + ")" ;
	}
}
