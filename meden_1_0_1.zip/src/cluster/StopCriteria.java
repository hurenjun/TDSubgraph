package cluster;

public class StopCriteria {
	public int numSplits = Integer.MAX_VALUE;
	public double sseFraction = Double.NEGATIVE_INFINITY;
	
	public StopCriteria(int _numSplits, double _sseFraction) {
		numSplits = _numSplits;
		sseFraction = _sseFraction;
	}
	
	public boolean stop(SplitTreeNode tree) {
		if (numSplits <= tree.numSplitDecendants()) return true;
		if (sseFraction >= tree.aggregateSSE()/tree.sse) return true;
		return false;
	}
	
}