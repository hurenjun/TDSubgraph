package cluster;

import graph.DistanceMeasure;
import graph.NodeWeightedTimeGraph;

import java.util.BitSet;
import java.util.HashSet;
import java.util.Random;

import org.jgrapht.demo.PerformanceDemo;

public class Common {
	
	public static enum GDIST {SP,EI};
	public static enum COMPRESS {PCA,FA,AVGL2};
	public static boolean DEBUG = false;
	
	public static double getMinDist(DistanceMeasure dm, HashSet<Integer> from,
			int nbr) {
		double d = Double.POSITIVE_INFINITY;
		for (int i: from) d = Math.min(d, dm.getD(nbr, i));
		return d;
	}

	public static double getCompressionDecay(NodeWeightedTimeGraph tg, int t,
			int lag, HashSet<Integer> from, int nbr, COMPRESS cm) {
		double d = -1.0;
		HashSet<Integer> expset = new HashSet<Integer>();
		expset.addAll(from);
		expset.add(nbr);
		switch (cm) {
			case AVGL2:
				d = getAvgL2(tg,t,lag,from,nbr);
				break;
		}
		return d;
	}

	public static double getAvgL2(NodeWeightedTimeGraph tg, int t, int lag,
			HashSet<Integer> from, int nbr) {
		double lambda = 1.0;
		double sum = 0;
		double tmp = 0;
		for (Integer n: from) {
			tmp = 0.0;
			for (int j = t-lag+1; j <=t; j++) {
				tmp += Math.pow(lambda, t-j)*Math.pow(tg.wsl[j][n] - tg.wsl[j][nbr],2);
			}
			sum += Math.sqrt(tmp);
		}
		sum /= from.size();
		return sum;
	}
	
	public static String toCompressedString(BitSet b, int sz) {
		String res = "{";
		int i = 0;
		while (!b.get(i) && i < sz) i++;
		if (i<sz) res += "" + i;
		i++;
		while (i < sz) {
			while (!b.get(i) && (i<sz) ) i++;
			if (i>=sz) break;
			if (res.endsWith("" + (i-1))) { // sequence
				while (b.get(i) && (i < sz)) i++;
				res += ":" + (i-1);
			} else { // new beginning
				res += "," + i;
			}
			i++;
		}
		return res + "}";
	}

	public static void getIndexPermutation(int[] perm) {
		Random r = new Random();
		for (int i = 1; i < perm.length; i++) {
			perm[i] = perm.length-i;
		}
		int a, b;
		int s;
		for (int i = 0; i < perm.length*perm.length; i++) {
			a = r.nextInt(perm.length);
			b = r.nextInt(perm.length);
			s = perm[a];
			perm[a] = perm[b];
			perm[b] = s;
		}
		
	}
}
